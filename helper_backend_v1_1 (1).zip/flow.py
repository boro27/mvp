def start_flow_timer():
    return {"status": "Flow Mode started for 90 minutes. Stay focused!"}

def log_flow(user_id):
    return {"message": f"Flow session logged for user: {user_id}"}