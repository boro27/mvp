def generate_daily_summary():
    return "Today you have 2 meetings and 3 tasks. Focus on completing your proposal and taking a break at 15:00."